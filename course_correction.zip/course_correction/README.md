The purpose of this code can be seen below.

